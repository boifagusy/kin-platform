<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\PlatformDashboardController;
use App\Http\Controllers\Admin\WatchtowerDashboardController;
use App\Http\Controllers\Admin\SafetyMonitorController;
use App\Http\Controllers\Admin\UserManagementController;
use App\Http\Controllers\Admin\SystemSettingsController;

Route::prefix('admin')->group(function () {
    // Public admin routes
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('admin.login');
    Route::post('/login', [AuthController::class, 'login'])->name('admin.login.submit');

    // Protected admin routes
    Route::middleware('admin.auth')->group(function () {
        // Dashboard
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('admin.dashboard');
        Route::get('/watchtower', [WatchtowerDashboardController::class, 'index'])->name('admin.watchtower');
        Route::get('/platform', [PlatformDashboardController::class, 'index'])->name('admin.platform');
        Route::post('/logout', [AuthController::class, 'logout'])->name('admin.logout');
        
        // Safety Monitor API
        Route::get('/safety/metrics', [SafetyMonitorController::class, 'getMetrics'])->name('admin.safety.metrics');
        Route::get('/safety/trend', [SafetyMonitorController::class, 'getTrendData'])->name('admin.safety.trend');
        
        // User Management
        Route::get('/users', [UserManagementController::class, 'index'])->name('admin.users.index');
        Route::get('/users/{id}', [UserManagementController::class, 'show'])->name('admin.users.show');
        Route::post('/users/{id}/activate', [UserManagementController::class, 'activate'])->name('admin.users.activate');
        Route::post('/users/{id}/suspend', [UserManagementController::class, 'suspend'])->name('admin.users.suspend');
        Route::get('/users/{id}/edit', [UserManagementController::class, 'edit'])->name('admin.users.edit');
        Route::put('/users/{id}', [UserManagementController::class, 'update'])->name('admin.users.update');
        Route::delete('/users/{id}', [UserManagementController::class, 'destroy'])->name('admin.users.destroy');
        Route::post('/users/{id}/restore', [UserManagementController::class, 'restore'])->name('admin.users.restore');
        Route::post('/users/bulk', [UserManagementController::class, 'bulkAction'])->name('admin.users.bulk');
        
        // Alert Management
        Route::get('/alerts', [SafetyMonitorController::class, 'alertsIndex'])->name('admin.alerts.index');
        Route::get('/alerts/{id}', [SafetyMonitorController::class, 'alertsShow'])->name('admin.alerts.show');
        Route::post('/alerts/{id}/assign', [SafetyMonitorController::class, 'assignAlert'])->name('admin.alerts.assign');
        Route::post('/alerts/{id}/resolve', [SafetyMonitorController::class, 'resolveAlert'])->name('admin.alerts.resolve');
        Route::post('/alerts/{id}/escalate', [SafetyMonitorController::class, 'escalateAlert'])->name('admin.alerts.escalate');
        Route::post('/alerts/{id}/note', [SafetyMonitorController::class, 'addAlertNote'])->name('admin.alerts.add-note');
    });
});

// Email Settings (outside admin prefix)
Route::prefix('admin')->group(function () {
    Route::get('/settings/email', [SystemSettingsController::class, 'emailSettings'])->name('admin.settings.email');
    Route::put('/settings/email', [SystemSettingsController::class, 'updateEmailSettings'])->name('admin.settings.email.update');
    Route::post('/settings/email/test', [SystemSettingsController::class, 'testEmail'])->name('admin.settings.email.test');
});
Route::get('/debug-sidebar', function() {
    return view('admin.debug-sidebar');
})->middleware('admin.auth');

// Admin Password Reset - Must be inside admin prefix
Route::prefix('admin')->group(function () {
});

// Admin Password Reset (OTP based)

// OTP verification endpoint

// Ensure JSON responses for API calls

// OTP verification page

// =============================================
// ADMIN PASSWORD RESET (Canonical Routes)
// =============================================
// Step 1: Request OTP (email form)
Route::get('/forgot-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'showForgotForm'])->name('admin.password.request');
Route::post('/forgot-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'sendOtp'])->name('admin.password.email');

// Step 2: Verify OTP
Route::get('/verify-otp', [App\Http\Controllers\Admin\PasswordResetController::class, 'showOtpForm'])->name('admin.password.otp.form');
Route::post('/verify-otp', [App\Http\Controllers\Admin\PasswordResetController::class, 'verifyOtp'])->name('admin.password.verify');

// Step 3: Reset password
Route::get('/reset-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'showResetForm'])->name('admin.password.reset.form');
Route::post('/reset-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'reset'])->name('admin.password.update');

// Admin Management

// Admin Management (with admin prefix)
Route::prefix('admin')->group(function () {
    Route::prefix('admins')->middleware(['admin.auth'])->group(function () {
        Route::get('/', [App\Http\Controllers\Admin\AdminManagementController::class, 'index'])->name('admin.admins.index');
        Route::get('/create', [App\Http\Controllers\Admin\AdminManagementController::class, 'create'])->name('admin.admins.create');
        Route::post('/', [App\Http\Controllers\Admin\AdminManagementController::class, 'store'])->name('admin.admins.store');
        Route::get('/{id}', [App\Http\Controllers\Admin\AdminManagementController::class, 'show'])->name('admin.admins.show');
        Route::get('/{id}/edit', [App\Http\Controllers\Admin\AdminManagementController::class, 'edit'])->name('admin.admins.edit');
        Route::put('/{id}', [App\Http\Controllers\Admin\AdminManagementController::class, 'update'])->name('admin.admins.update');
        Route::post('/{id}/activate', [App\Http\Controllers\Admin\AdminManagementController::class, 'activate'])->name('admin.admins.activate');
        Route::post('/{id}/deactivate', [App\Http\Controllers\Admin\AdminManagementController::class, 'deactivate'])->name('admin.admins.deactivate');
    });
});

// Admin Password Reset Routes
Route::get('/forgot-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'showForgotForm'])->name('admin.password.request');
Route::post('/forgot-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'sendOtp'])->name('admin.password.email');
Route::get('/verify-otp', [App\Http\Controllers\Admin\PasswordResetController::class, 'showOtpForm'])->name('admin.password.otp.form');
Route::post('/verify-otp', [App\Http\Controllers\Admin\PasswordResetController::class, 'verifyOtp'])->name('admin.password.verify');
Route::get('/reset-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'showResetForm'])->name('admin.password.reset.form');
Route::post('/reset-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'reset'])->name('admin.password.update');

// Admin Password Reset (with admin prefix)
Route::get('/forgot-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'showForgotForm'])->name('admin.password.request');
Route::post('/forgot-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'sendOtp'])->name('admin.password.email');
Route::get('/verify-otp', [App\Http\Controllers\Admin\PasswordResetController::class, 'showOtpForm'])->name('admin.password.otp.form');
Route::post('/verify-otp', [App\Http\Controllers\Admin\PasswordResetController::class, 'verifyOtp'])->name('admin.password.verify');
Route::get('/reset-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'showResetForm'])->name('admin.password.reset.form');
Route::post('/reset-password', [App\Http\Controllers\Admin\PasswordResetController::class, 'reset'])->name('admin.password.update');

Route::middleware('admin.auth')->prefix('admin')->group(function () {
    Route::get('/analytics', [App\Http\Controllers\Admin\AnalyticsController::class, 'index'])->name('admin.analytics');
    Route::get('/analytics/api', [App\Http\Controllers\Admin\AnalyticsController::class, 'api'])->name('admin.analytics.api');
});

Route::middleware('admin.auth')->prefix('admin/announcements')->name('admin.announcements.')->group(function () {
    Route::get('/', [App\Http\Controllers\Admin\AnnouncementManagerController::class, 'index'])->name('index');
    Route::get('/create', [App\Http\Controllers\Admin\AnnouncementManagerController::class, 'create'])->name('create');
    Route::post('/', [App\Http\Controllers\Admin\AnnouncementManagerController::class, 'store'])->name('store');
    Route::get('/{announcement}/edit', [App\Http\Controllers\Admin\AnnouncementManagerController::class, 'edit'])->name('edit');
    Route::put('/{announcement}', [App\Http\Controllers\Admin\AnnouncementManagerController::class, 'update'])->name('update');
    Route::delete('/{announcement}', [App\Http\Controllers\Admin\AnnouncementManagerController::class, 'destroy'])->name('destroy');
});

Route::middleware('admin.auth')->prefix('admin/campaigns')->name('admin.campaigns.')->group(function () {
    Route::get('/', [App\Http\Controllers\Admin\CampaignManagerController::class, 'index'])->name('index');
    Route::get('/create', [App\Http\Controllers\Admin\CampaignManagerController::class, 'create'])->name('create');
    Route::post('/', [App\Http\Controllers\Admin\CampaignManagerController::class, 'store'])->name('store');
    Route::get('/{campaign}/edit', [App\Http\Controllers\Admin\CampaignManagerController::class, 'edit'])->name('edit');
    Route::put('/{campaign}', [App\Http\Controllers\Admin\CampaignManagerController::class, 'update'])->name('update');
    Route::delete('/{campaign}', [App\Http\Controllers\Admin\CampaignManagerController::class, 'destroy'])->name('destroy');
});

Route::middleware('admin.auth')->prefix('admin/broadcasts')->name('admin.broadcasts.')->group(function () {
    Route::get('/', [App\Http\Controllers\Admin\BroadcastManagerController::class, 'index'])->name('index');
    Route::get('/create', [App\Http\Controllers\Admin\BroadcastManagerController::class, 'create'])->name('create');
    Route::post('/', [App\Http\Controllers\Admin\BroadcastManagerController::class, 'store'])->name('store');
    Route::get('/{broadcast}/edit', [App\Http\Controllers\Admin\BroadcastManagerController::class, 'edit'])->name('edit');
    Route::put('/{broadcast}', [App\Http\Controllers\Admin\BroadcastManagerController::class, 'update'])->name('update');
    Route::delete('/{broadcast}', [App\Http\Controllers\Admin\BroadcastManagerController::class, 'destroy'])->name('destroy');
});

Route::middleware('admin.auth')->prefix('admin/templates')->name('admin.templates.')->group(function () {
    Route::get('/', [App\Http\Controllers\Admin\TemplateManagerController::class, 'index'])->name('index');
    Route::get('/create', [App\Http\Controllers\Admin\TemplateManagerController::class, 'create'])->name('create');
    Route::post('/', [App\Http\Controllers\Admin\TemplateManagerController::class, 'store'])->name('store');
    Route::get('/{template}/edit', [App\Http\Controllers\Admin\TemplateManagerController::class, 'edit'])->name('edit');
    Route::put('/{template}', [App\Http\Controllers\Admin\TemplateManagerController::class, 'update'])->name('update');
    Route::delete('/{template}', [App\Http\Controllers\Admin\TemplateManagerController::class, 'destroy'])->name('destroy');
});

// N7: Notification Analytics & Management
Route::middleware(['web', 'admin.auth'])->prefix('admin/analytics')->group(function () {
    Route::get('/notifications', [App\Http\Controllers\Admin\AnalyticsController::class, 'notifications'])->name('admin.analytics.notifications');
    Route::get('/notifications/trends', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationTrends'])->name('admin.analytics.notifications.trends');
    Route::get('/notifications/channels', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationChannels'])->name('admin.analytics.notifications.channels');
    Route::get('/notifications/failures', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationFailures'])->name('admin.analytics.notifications.failures');
    Route::get('/notifications/manage', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationManage'])->name('admin.analytics.notifications.manage');
    Route::get('/notifications/{id}', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationShow'])->name('admin.analytics.notifications.show');
    Route::post('/notifications/{id}/retry', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationRetry'])->name('admin.analytics.notifications.retry');
    Route::post('/notifications/retry-bulk', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationRetryBulk'])->name('admin.analytics.notifications.retry-bulk');
});

// N10: Rate-limited notification analytics + automation dashboard
Route::middleware(['web', 'admin.auth', 'throttle:admin-notifications'])->prefix('admin/analytics/notifications')->group(function () {
    Route::get('/', [App\Http\Controllers\Admin\AnalyticsController::class, 'notifications'])->name('admin.analytics.notifications');
    Route::get('/trends', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationTrends'])->name('admin.analytics.notifications.trends');
    Route::get('/channels', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationChannels'])->name('admin.analytics.notifications.channels');
    Route::get('/failures', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationFailures'])->name('admin.analytics.notifications.failures');
    Route::get('/manage', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationManage'])->name('admin.analytics.notifications.manage');
    Route::get('/{id}', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationShow'])->name('admin.analytics.notifications.show');
    Route::post('/{id}/retry', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationRetry'])->name('admin.analytics.notifications.retry');
    Route::post('/retry-bulk', [App\Http\Controllers\Admin\AnalyticsController::class, 'notificationRetryBulk'])->name('admin.analytics.notifications.retry-bulk');
});

// N10: Automation Dashboard (deferred from N9)
Route::middleware(['web', 'admin.auth'])->prefix('admin/automation')->group(function () {
    Route::get('/logs', [App\Http\Controllers\Admin\AutomationController::class, 'logs'])->name('admin.automation.logs');
    Route::post('/test', [App\Http\Controllers\Admin\AutomationController::class, 'test'])->name('admin.automation.test');
});

// B5: Version Manager — Release Operations
Route::middleware(['web', 'admin.auth'])->prefix('admin/versions')->group(function () {
    Route::get('/', [App\Http\Controllers\Admin\VersionManagerController::class, 'index'])->name('admin.versions.index');
    Route::get('/create', [App\Http\Controllers\Admin\VersionManagerController::class, 'create'])->name('admin.versions.create');
    Route::post('/', [App\Http\Controllers\Admin\VersionManagerController::class, 'store'])->name('admin.versions.store');
    Route::get('/{version}/edit', [App\Http\Controllers\Admin\VersionManagerController::class, 'edit'])->name('admin.versions.edit');
    Route::put('/{version}', [App\Http\Controllers\Admin\VersionManagerController::class, 'update'])->name('admin.versions.update');
    Route::delete('/{version}', [App\Http\Controllers\Admin\VersionManagerController::class, 'destroy'])->name('admin.versions.destroy');
    Route::post('/{version}/activate', [App\Http\Controllers\Admin\VersionManagerController::class, 'activate'])->name('admin.versions.activate');
    Route::post('/{id}/restore', [App\Http\Controllers\Admin\VersionManagerController::class, 'restore'])->name('admin.versions.restore');
    Route::get('/analytics', [App\Http\Controllers\Admin\VersionManagerController::class, 'analytics'])->name('admin.versions.analytics');

    // Channels
    Route::get('/{version}/channels', [App\Http\Controllers\Admin\VersionManagerController::class, 'channels'])->name('admin.versions.channels');
    Route::post('/{version}/channels', [App\Http\Controllers\Admin\VersionManagerController::class, 'storeChannel'])->name('admin.versions.channels.store');
    Route::delete('/channels/{channel}', [App\Http\Controllers\Admin\VersionManagerController::class, 'destroyChannel'])->name('admin.versions.channels.destroy');

    // Policies
    Route::get('/{version}/policies', [App\Http\Controllers\Admin\VersionManagerController::class, 'policies'])->name('admin.versions.policies');
    Route::post('/{version}/policies', [App\Http\Controllers\Admin\VersionManagerController::class, 'storePolicy'])->name('admin.versions.policies.store');
    Route::put('/policies/{policy}', [App\Http\Controllers\Admin\VersionManagerController::class, 'updatePolicy'])->name('admin.versions.policies.update');
    Route::delete('/policies/{policy}', [App\Http\Controllers\Admin\VersionManagerController::class, 'destroyPolicy'])->name('admin.versions.policies.destroy');
});

// B7: Release Governance
Route::middleware(['web', 'admin.auth'])->prefix('admin/versions')->group(function () {
    Route::post('/{version}/submit', [App\Http\Controllers\Admin\VersionManagerController::class, 'submit'])->name('admin.versions.submit');
    Route::post('/{version}/approve', [App\Http\Controllers\Admin\VersionManagerController::class, 'approve'])
        ->middleware('release.permission:release.approve')->name('admin.versions.approve');
    Route::post('/{version}/reject', [App\Http\Controllers\Admin\VersionManagerController::class, 'reject'])
        ->middleware('release.permission:release.approve')->name('admin.versions.reject');
    Route::post('/{version}/archive', [App\Http\Controllers\Admin\VersionManagerController::class, 'archive'])
        ->middleware('release.permission:release.archive')->name('admin.versions.archive');
});
