<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Admin\UserManagementService;
use App\Models\User;
use App\Services\Admin\UserActionService;
use Illuminate\Http\Request;

class UserManagementController extends Controller
{
    protected $userService;

    public function __construct(UserManagementService $userService)
    {
        $this->userService = $userService;
    }

    public function index(Request $request)
    {
        $filters = [
            'search' => $request->get('search'),
            'sort_by' => $request->get('sort_by', 'created_at'),
            'sort_direction' => $request->get('sort_direction', 'desc'),
        ];

        $users = $this->userService->getUsersList($filters);
        $stats = $this->userService->getStats();

        return view('admin.users.index', compact('users', 'stats', 'filters'));
    }

    public function show($id)
    {
        $user = $this->userService->getUserDetail($id);

        if (!$user) {
            abort(404, 'User not found');
        }

        return view('admin.users.show', compact('user'));
    }

    public function suspend(Request $request, $id)
    {
        $request->validate([
            'reason' => 'required|string|min:5|max:500',
            'notes' => 'nullable|string|max:1000',
        ]);

        $user = User::findOrFail($id);
        $userActionService = new UserActionService();

        $success = $userActionService->suspendUser($user, $request->reason, $request->notes ?? null);

        if ($success) {
            return response()->json(['success' => true, 'message' => 'User suspended successfully']);
        }

        return response()->json(['success' => false, 'message' => 'Failed to suspend user'], 500);
    }

    public function activate($id)
    {
        $user = User::findOrFail($id);
        $userActionService = new UserActionService();

        $success = $userActionService->activateUser($user);

        if ($success) {
            return response()->json(['success' => true, 'message' => 'User activated successfully']);
        }

        return response()->json(['success' => false, 'message' => 'Failed to activate user'], 500);
    }

    /**
     * Show edit user form
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('admin.users.edit', compact('user'));
    }

    /**
     * Update user
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email,' . $id,
            'phone' => 'required|string|max:20|unique:users,phone,' . $id,
            'status' => 'required|in:active,suspended,pending',
        ]);

        $user = User::findOrFail($id);
        $user->update($request->only(['name', 'email', 'phone', 'status']));

        return redirect()->route('admin.users.show', $user->id)
            ->with('success', 'User updated successfully');
    }

    /**
     * Soft delete user
     */
    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('admin.users.index')
            ->with('success', 'User deleted successfully');
    }

    /**
     * Restore soft deleted user
     */
    public function restore($id)
    {
        $user = User::withTrashed()->findOrFail($id);
        $user->restore();

        return redirect()->route('admin.users.index')
            ->with('success', 'User restored successfully');
    }

    /**
     * Bulk action on users
     */
    public function bulkAction(Request $request)
    {
        $request->validate([
            'user_ids' => 'required|array',
            'user_ids.*' => 'exists:users,id',
            'action' => 'required|in:delete,restore,suspend,activate',
        ]);

        $action = $request->action;
        $userIds = $request->user_ids;

        switch ($action) {
            case 'delete':
                User::whereIn('id', $userIds)->delete();
                $message = 'Users deleted successfully';
                break;
            case 'restore':
                User::withTrashed()->whereIn('id', $userIds)->restore();
                $message = 'Users restored successfully';
                break;
            case 'suspend':
                User::whereIn('id', $userIds)->update(['status' => 'suspended']);
                $message = 'Users suspended successfully';
                break;
            case 'activate':
                User::whereIn('id', $userIds)->update(['status' => 'active']);
                $message = 'Users activated successfully';
                break;
            default:
                return back()->with('error', 'Invalid action');
        }

        return redirect()->route('admin.users.index')->with('success', $message);
    }
}
