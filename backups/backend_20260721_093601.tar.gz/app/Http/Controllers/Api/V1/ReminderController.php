<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Responses\ApiResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ReminderController extends Controller
{
    public function check(Request $request)
    {
        $user = $request->user();

        // Get setting directly from database
        $setting = DB::table('checkin_settings')->where('user_id', $user->id)->first();

        if (!$setting || !$setting->enabled) {
            return ApiResponse::success([
                'should_remind' => false,
                'checkin_time' => $setting->checkin_time ?? '21:00',
                'message' => null,
            ]);
        }

        $now = Carbon::now();
        $currentHour = (int)$now->format('H');
        $currentMinute = (int)$now->format('i');

        // Parse checkin time from setting (format "09:32")
        $parts = explode(':', $setting->checkin_time);
        $checkinHour = (int)$parts[0];
        $checkinMinute = (int)$parts[1];

        // Calculate total minutes for comparison
        $currentTotalMinutes = $currentHour * 60 + $currentMinute;
        $checkinTotalMinutes = $checkinHour * 60 + $checkinMinute;

        // For testing: trigger reminder if current time is within 30 minutes of checkin time
        $diffMinutes = abs($currentTotalMinutes - $checkinTotalMinutes);

        // Also check if current time is at or after checkin time (within 1 hour window)
        $isAtOrAfterCheckin = ($currentTotalMinutes >= $checkinTotalMinutes);
        $isWithinWindow = ($isAtOrAfterCheckin && $diffMinutes <= 60);

        // FORCE TRIGGER FOR TESTING - remove after testing
        // This will make it return true for you to see the popup        $forceTrigger = true;

        if (!$forceTrigger && !$isWithinWindow) {
            return ApiResponse::success([
                'should_remind' => false,
                'checkin_time' => substr($setting->checkin_time, 0, 5),
                'message' => null,
                'debug' => [
                    'current_time' => $now->format('H:i'),
                    'checkin_time' => $setting->checkin_time,
                    'diff_minutes' => $diffMinutes,
                ]
            ]);
        }

        // Check if user already checked in today
        $hasCheckedIn = DB::table('check_ins')
            ->where('user_id', $user->id)
            ->whereDate('checked_in_at', $now->toDateString())
            ->exists();

        if ($hasCheckedIn) {
            return ApiResponse::success([
                'should_remind' => false,
                'checkin_time' => substr($setting->checkin_time, 0, 5),
                'message' => null,
            ]);
        }

        // Check if reminder already sent today
        $reminderSent = DB::table('activity_logs')
            ->where('user_id', $user->id)
            ->where('type', 'CHECKIN_REMINDER_SENT')
            ->whereDate('occurred_at', $now->toDateString())
            ->exists();

        if (!$reminderSent) {
            DB::table('activity_logs')->insert([
                'user_id' => $user->id,
                'type' => 'CHECKIN_REMINDER_SENT',
                'status' => 'pending',
                'details' => 'Reminder sent for daily check-in',
                'occurred_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return ApiResponse::success([
            'should_remind' => true,            'checkin_time' => substr($setting->checkin_time, 0, 5),
            'message' => '⚠️ TEST - Time for your daily safety check-in!',
        ]);
    }
}
