<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PasswordReset extends Model
{
    protected $table = 'password_resets';
    
    protected $fillable = [
        'phone',
        'otp',
        'expires_at',
        'used',
    ];
    
    protected $casts = [
        'expires_at' => 'datetime',
        'used' => 'boolean',
    ];
}
