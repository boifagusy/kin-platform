// frontend/src/services/api.js
// API service for KIN frontend

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

// Helper to get auth token
const getToken = () => localStorage.getItem('kin_token');

// Helper headers
const getHeaders = () => ({
  'Content-Type': 'application/json',
  'Accept': 'application/json',
  ...(getToken() && { 'Authorization': `Bearer ${getToken()}` })
});

// Generic request handler
async function request(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  console.log('📡 API Request:', url);

  try {
    const response = await fetch(url, {
      ...options,
      headers: { ...getHeaders(), ...options.headers }
    });

    // Check if response is JSON
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      const text = await response.text();
      console.error('❌ Non-JSON response:', text.substring(0, 100));
      throw new Error('Server returned non-JSON response');
    }

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || data.error || 'Request failed');
    }

    return data;
  } catch (error) {
    console.error('❌ API Error:', error.message);
    throw error;
  }
}

// ============= AUTH ENDPOINTS =============

// Check if phone exists
export const checkPhone = async (phone) => {
  return request('/auth/check-phone', {
    method: 'POST',
    body: JSON.stringify({ phone })
  });
};

// Confirm phone with last 4 digits
export const confirmPhone = async (phone, lastFourDigits) => {
  return request('/auth/confirm-phone', {
    method: 'POST',
    body: JSON.stringify({ phone, last_four_digits: lastFourDigits })
  });
};

// Create login PIN
export const createPin = async (pin, pinConfirmation) => {
  return request('/auth/create-pin', {
    method: 'POST',
    body: JSON.stringify({ pin, pin_confirmation: pinConfirmation })
  });
};

// Login with PIN
export const loginPin = async (phone, pin) => {
  return request('/auth/login-pin', {
    method: 'POST',
    body: JSON.stringify({ phone, pin })
  });
};

// Save user details (name, email)
export const saveUserDetails = async (phone, fullName, email) => {
  return request('/auth/user-details', {
    method: 'POST',
    body: JSON.stringify({ phone, full_name: fullName, email })
  });
};

// Save trusted contact
export const saveTrustedContact = async (data) => {
  return request('/auth/trusted-contact', {
    method: 'POST',
    body: JSON.stringify(data)
  });
};

// Complete onboarding
export const completeOnboarding = async () => {
  return request('/auth/complete-onboarding', {
    method: 'POST'
  });
};

// ============= TRUSTED CONTACTS ENDPOINTS =============

// Get all trusted contacts
export const getTrustedContacts = async () => {
  return request('/trusted-contacts', {
    method: 'GET'
  });
};

// Delete trusted contact
export const deleteTrustedContact = async (id) => {
  return request(`/trusted-contacts/${id}`, {
    method: 'DELETE'
  });
};

// ============= CHECK-IN ENDPOINTS =============

// Send check-in
export const sendCheckIn = async (status = 'safe', location = null) => {
  return request('/checkin', {
    method: 'POST',
    body: JSON.stringify({ status, location })
  });
};

// Get check-in status
export const getCheckInStatus = async () => {
  return request('/checkin/status', {
    method: 'GET'
  });
};

// ============= SOS / DURESS ENDPOINTS =============

// Activate duress mode (secret emergency)
export const activateDuress = async (location = null) => {
  return request('/duress/activate', {
    method: 'POST',
    body: JSON.stringify({ location })
  });
};

// Get SOS history
export const getSosHistory = async () => {
  return request('/sos/history', {
    method: 'GET'
  });
};

// ============= DASHBOARD ENDPOINTS =============

// Get dashboard data
export const getDashboard = async () => {
  return request('/dashboard', {
    method: 'GET'
  });
};

// Get safety stats
export const getSafetyStats = async () => {
  return request('/safety/stats', {
    method: 'GET'
  });
};

// ============= ONBOARDING DRAFT ENDPOINTS =============

// Get onboarding draft
export const getOnboardingDraft = async () => {
  return request('/onboarding/draft', {
    method: 'GET'
  });
};

// Save onboarding draft
export const saveOnboardingDraft = async (data) => {
  return request('/onboarding/draft', {
    method: 'POST',
    body: JSON.stringify(data)
  });
};

export default {
  checkPhone,
  confirmPhone,
  createPin,
  loginPin,
  saveUserDetails,
  saveTrustedContact,
  completeOnboarding,
  getTrustedContacts,
  deleteTrustedContact,
  sendCheckIn,
  getCheckInStatus,
  activateDuress,
  getSosHistory,
  getDashboard,
  getSafetyStats,
  getOnboardingDraft,
  saveOnboardingDraft
};
