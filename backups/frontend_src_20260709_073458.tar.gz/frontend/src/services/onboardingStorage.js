const DRAFT_KEY = 'kin_onboarding_draft';

export const STEPS = {
  WELCOME: 'welcome',
  PHONE: 'phone',
  PIN: 'pin',
  USER_DETAILS: 'user-details',
  CHECKIN: 'checkin',
  DURESS: 'duress',
  DASHBOARD: 'dashboard',
  COMPLETE: 'complete',
};

export function getDraft() {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (error) {
    console.error('Error reading onboarding draft:', error);
    return null;
  }
}

export function saveDraft(data) {
  try {
    const existing = getDraft();
    const draft = {
      step: data.step || existing?.step || STEPS.WELCOME,
      phone: data.phone || existing?.phone || null,
      profile: {
        name: data.profile?.name || existing?.profile?.name || '',
        email: data.profile?.email || existing?.profile?.email || '',
      },
      checkin: {
        frequency: data.checkin?.frequency || existing?.checkin?.frequency || 'daily',
        time: data.checkin?.time || existing?.checkin?.time || '20:00',
      },
      created_at: existing?.created_at || Date.now(),
      updated_at: Date.now(),
    };
    localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
    return draft;
  } catch (error) {
    console.error('Error saving onboarding draft:', error);
    return null;
  }
}

export function updateStep(step) {
  const draft = getDraft();
  if (!draft) return null;
  draft.step = step;
  draft.updated_at = Date.now();
  localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
  return draft;
}

export function updatePhone(phone) {
  const draft = getDraft();
  if (!draft) return null;
  draft.phone = phone;
  draft.updated_at = Date.now();
  localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
  return draft;
}

export function updateProfile(profile) {
  const draft = getDraft();
  if (!draft) return null;
  draft.profile = { ...draft.profile, ...profile };
  draft.updated_at = Date.now();
  localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
  return draft;
}

export function updateCheckin(checkin) {
  const draft = getDraft();
  if (!draft) return null;
  draft.checkin = { ...draft.checkin, ...checkin };
  draft.updated_at = Date.now();
  localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
  return draft;
}

export function clearDraft() {
  try {
    localStorage.removeItem(DRAFT_KEY);
    return true;
  } catch (error) {
    console.error('Error clearing onboarding draft:', error);
    return false;
  }
}

export function hasDraft() {
  return getDraft() !== null;
}

export function getStep() {
  const draft = getDraft();
  return draft?.step || null;
}

export function getPhone() {
  const draft = getDraft();
  return draft?.phone || null;
}

export function getProfile() {
  const draft = getDraft();
  return draft?.profile || null;
}

export function getCheckin() {
  const draft = getDraft();
  return draft?.checkin || null;
}

export function getLastUpdated() {
  const draft = getDraft();
  return draft?.updated_at || null;
}

export function isOnboardingComplete() {
  const draft = getDraft();
  return draft?.step === STEPS.COMPLETE;
}

export function formatTimeAgo(timestamp) {
  if (!timestamp) return 'recently';
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  
  if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
  if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  return 'just now';
}
