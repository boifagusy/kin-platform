const DRAFT_KEY = 'kin_onboarding_draft';

export const STEPS = {
  WELCOME: 'welcome',
  PHONE: 'phone',
  PIN: 'pin',
  USER_DETAILS: 'user-details',
  CHECKIN: 'checkin',
  DURESS: 'duress',
  DASHBOARD: 'dashboard',
  COMPLETE: 'complete',
};

export function getDraft() {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (error) {
    console.error('Error reading onboarding draft:', error);
    return null;
  }
}

export function saveDraft(data) {
  try {
    const existing = getDraft() || {};
    const draft = {
      step: data.step || existing.step || STEPS.WELCOME,
      phone: data.phone || existing.phone || null,
      name: data.name || existing.name || null,
      ...data,
    };
    localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
    return draft;
  } catch (error) {
    console.error('Error saving onboarding draft:', error);
    return null;
  }
}

export function clearDraft() {
  try {
    localStorage.removeItem(DRAFT_KEY);
  } catch (error) {
    console.error('Error clearing onboarding draft:', error);
  }
}

export function hasDraft() {
  return getDraft() !== null;
}

export function formatTimeAgo(timestamp) {
  if (!timestamp) return 'recently';
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return 'just now';
}

// ─── API SYNC ───
import api from './api';

export async function saveToServer(draftData) {
  try {
    const response = await api.post('/onboarding/draft', draftData);
    return response.data;
  } catch (error) {
    console.error('Error saving draft to server:', error);
    return null;
  }
}

export async function loadFromServer() {
  try {
    const response = await api.get('/onboarding/draft');
    if (response.data && response.data.data) {
      return response.data.data;
    }
    return null;
  } catch (error) {
    console.error('Error loading draft from server:', error);
    return null;
  }
}

export async function syncDraft() {
  const localDraft = getDraft();
  if (localDraft) {
    await saveToServer(localDraft);
  }
  const serverDraft = await loadFromServer();
  if (serverDraft) {
    const current = getDraft() || {};
    const merged = {
      ...current,
      ...serverDraft.draft,
      step: serverDraft.step || current.step
    };
    saveDraft(merged);
    return merged;
  }
  return localDraft;
}

// ─── V2 COMPATIBILITY FUNCTIONS ───
export function updatePhone(phone) {
    return saveDraft({ phone });
}

export function updateStep(step) {
    return saveDraft({ step });
}

export function getPhone() {
    const draft = getDraft();
    return draft?.phone || null;
}

export function updateProfile(profile) {
    return saveDraft({ ...profile });
}

// ─── ADDITIONAL COMPATIBILITY FUNCTIONS ───
export function updateCheckin(checkinData) {
    return saveDraft({ checkin: checkinData });
}

export function getStep() {
    const draft = getDraft();
    return draft?.step || STEPS.WELCOME;
}
