import { useState } from "react";
import {
  useNavigate,
  useLocation,
} from "react-router-dom";
import { FaArrowLeft, FaUser, FaEnvelope } from "react-icons/fa";

function UserDetailsScreen() {
  const navigate = useNavigate();
  const location = useLocation();
  const phone = location.state?.phone;

  console.log("PHONE:", phone);

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const canContinue = fullName.trim().length >= 3;

  async function handleContinue() {
    try {
      setLoading(true);
      setError("");

      console.log("Sending request with:", { phone, full_name: fullName, email });

      const response = await fetch(
        `${import.meta.env.VITE_API_URL}/auth/user-details",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            phone,
            full_name: fullName,
            email: email || "", // Send empty string instead of null
          }),
        }
      );

      const data = await response.json();
      
      console.log("USER DETAILS RESPONSE:", data);
      console.log("STATUS:", response.status);

      if (!response.ok) {
        throw new Error(data.error || data.message || "Unable to save details");
      }

      console.log("Success! Navigating to checkin-settings with phone:", phone);
      alert("Success! Going to Check-In Settings");
      
      // Navigate to trusted contact screen
      navigate("/checkin-settings", {
        state: {
          phone: phone,
        },
      });
    } catch (error) {
      console.error("ERROR:", error);
      alert("Error: " + error.message);
      setError(error.message || "Unable to save details");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background:
          "linear-gradient(180deg,#F8FBF9 0%,#EDF5F0 100%)",
        display: "flex",
        justifyContent: "center",
        padding: "24px",
        boxSizing: "border-box",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "430px",
          paddingTop: "24px",
        }}
      >
        <button
          onClick={() => navigate(-1)}
          style={{
            border: "none",
            background: "transparent",
            cursor: "pointer",
            marginBottom: "20px",
          }}
        >
          <FaArrowLeft size={20} />
        </button>

        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "10px",
            marginBottom: "32px",
          }}
        >
          <div
            style={{
              width: "12px",
              height: "12px",
              borderRadius: "50%",
              background: "#1A5632",
            }}
          />
          <div
            style={{
              width: "12px",
              height: "12px",
              borderRadius: "50%",
              background: "#D4A017",
            }}
          />
          <div
            style={{
              width: "12px",
              height: "12px",
              borderRadius: "50%",
              background: "#D1D5DB",
            }}
          />
          <div
            style={{
              width: "12px",
              height: "12px",
              borderRadius: "50%",
              background: "#D1D5DB",
            }}
          />
        </div>

        <h1
          style={{
            textAlign: "center",
            color: "#111827",
            fontSize: "32px",
            fontWeight: "800",
            marginBottom: "10px",
          }}
        >
          Tell us about yourself
        </h1>

        <div
          style={{
            color: "#1A5632",
            textAlign: "center",
            marginBottom: "20px",
            padding: "10px",
            background: "#EDF5F0",
            borderRadius: "10px",
            fontSize: "14px",
            fontWeight: "bold",
          }}
        >
          📱 Phone: {phone || "UNDEFINED"}
        </div>

        <p
          style={{
            textAlign: "center",
            color: "#6B7280",
            marginBottom: "36px",
            lineHeight: "24px",
          }}
        >
          This helps us recover your
          account if you lose access.
        </p>

        <div
          style={{
            background: "#FFFFFF",
            borderRadius: "20px",
            padding: "18px",
            display: "flex",
            alignItems: "center",
            gap: "16px",
            marginBottom: "16px",
            boxShadow:
              "0 4px 12px rgba(0,0,0,.05)",
          }}
        >
          <FaUser
            size={20}
            color="#1A5632"
          />
          <input
            type="text"
            placeholder="Full Name"
            value={fullName}
            onChange={(e) =>
              setFullName(e.target.value)
            }
            style={{
              flex: 1,
              border: "none",
              outline: "none",
              fontSize: "18px",
            }}
          />
        </div>

        <div
          style={{
            background: "#FFFFFF",
            borderRadius: "20px",
            padding: "18px",
            display: "flex",
            alignItems: "center",
            gap: "16px",
            marginBottom: "24px",
            boxShadow:
              "0 4px 12px rgba(0,0,0,.05)",
          }}
        >
          <FaEnvelope
            size={20}
            color="#6B7280"
          />
          <input
            type="email"
            placeholder="Email (Optional)"
            value={email}
            onChange={(e) =>
              setEmail(e.target.value)
            }
            style={{
              flex: 1,
              border: "none",
              outline: "none",
              fontSize: "18px",
            }}
          />
        </div>

        {error && (
          <div
            style={{
              color: "#DC2626",
              textAlign: "center",
              marginBottom: "20px",
            }}
          >
            {error}
          </div>
        )}

        <div
          style={{
            textAlign: "center",
            color: "#16A34A",
            marginBottom: "36px",
            fontSize: "15px",
          }}
        >
          🛡 Your information is encrypted
          and never shared.
        </div>

        <button
          disabled={!canContinue || loading}
          onClick={handleContinue}
          style={{
            width: "100%",
            height: "64px",
            border: "none",
            borderRadius: "20px",
            background:
              canContinue && !loading
                ? "linear-gradient(90deg,#1A5632,#3A7D44)"
                : "#B7D4BF",
            color: "#FFFFFF",
            fontSize: "18px",
            fontWeight: "700",
            cursor: "pointer",
          }}
        >
          {loading ? "Saving..." : "Continue"}
        </button>
      </div>
    </div>
  );
}

export default UserDetailsScreen;
