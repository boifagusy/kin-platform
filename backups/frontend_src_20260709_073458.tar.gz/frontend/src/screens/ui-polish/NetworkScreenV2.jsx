import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import BottomNav from "../../components/dashboard/BottomNav";
import { FaArrowLeft, FaUserCircle, FaShareAlt, FaSync, FaTrash, FaClock, FaCheckCircle, FaExclamationTriangle } from "react-icons/fa";
import InviteModal from "../../components/trusted-contact/InviteModal";

const API_BASE = import.meta.env.VITE_API_URL;

function NetworkScreenV2() {
  const location = useLocation();
  const navigate = useNavigate();
  const phone = location.state?.phone || localStorage.getItem("kin_phone");

  const [loading, setLoading] = useState(true);
  const [contact, setContact] = useState(null);
  const [limit, setLimit] = useState(1);
  const [used, setUsed] = useState(0);
  const [canAdd, setCanAdd] = useState(true);
  const [canRemove, setCanRemove] = useState(true);
  const [daysUntilRemoval, setDaysUntilRemoval] = useState(0);
  const [removalCooldownDays, setRemovalCooldownDays] = useState(30);
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [showRemoveConfirm, setShowRemoveConfirm] = useState(false);
  const [formData, setFormData] = useState({ name: "", contact_phone: "" });
  const [formError, setFormError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [shareMessage, setShareMessage] = useState("");
  const [shareError, setShareError] = useState("");

  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteSent, setInviteSent] = useState(false);
  const [newContactName, setNewContactName] = useState("");
  const [newContactPhone, setNewContactPhone] = useState("");
  const [verificationToken, setVerificationToken] = useState(null);

  const verifyLink = verificationToken
    ? `${API_BASE}/trusted-contact/verify/${verificationToken}`
    : "";

  const inviteMessage = `Hi ${newContactName || "there"},

You've been added as a trusted contact in KIN.

You may receive alerts if a check-in is missed or SOS is activated.

Please confirm you're willing to be their trusted contact:
${verifyLink}

Download Kin:
https://kin.app`;

  const handleSmsShare = () => {
    window.open(`sms:${newContactPhone}?body=${encodeURIComponent(inviteMessage)}`);
    setInviteSent(true);
  };

  const handleWhatsappShare = () => {
    const cleaned = newContactPhone.replace(/\D/g, "");
    window.open(`https://wa.me/${cleaned}?text=${encodeURIComponent(inviteMessage)}`);
    setInviteSent(true);
  };

  const handleInviteContinue = () => {
    setShowInviteModal(false);
    setInviteSent(false);
    setVerificationToken(null);
  };

  // Get authentication headers
  const getAuthHeaders = () => {
    const token = localStorage.getItem('kin_token') || '';
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'XMLHttpRequest',
    };
  };

  useEffect(() => {
    if (!phone) {
      navigate("/login");
      return;
    }
    fetchContact();
  }, [phone]);

  const fetchContact = async () => {
    try {
      const response = await fetch(`${API_BASE}/trusted-contacts?phone=${encodeURIComponent(phone)}`, {
        headers: getAuthHeaders(),
      });
      const data = await response.json();

      if (data.success) {
        const contactData = data.data.contacts && data.data.contacts.length > 0 ? data.data.contacts[0] : null;
        setContact(contactData);
        setLimit(data.data.limit);
        setUsed(data.data.used);
        setCanAdd(data.data.can_add);
        setRemovalCooldownDays(data.data.removal_cooldown_days || 30);
        
        if (contactData) {
          setCanRemove(contactData.can_remove !== false);
          setDaysUntilRemoval(contactData.days_until_removal || 0);
        }
      }
    } catch (error) {
      console.error("Error fetching contact:", error);
    } finally {
      setLoading(false);
    }
  };

  const validatePhoneNumber = (phoneNumber) => {
    const cleaned = phoneNumber.replace(/\D/g, '');
    if (cleaned.length === 10 || cleaned.length === 11) {
      return { valid: true, formatted: `+234${cleaned}` };
    } else if (cleaned.length === 13 && cleaned.startsWith('234')) {
      return { valid: true, formatted: `+${cleaned}` };
    } else if (cleaned.length === 14 && cleaned.startsWith('0')) {
      return { valid: true, formatted: `+234${cleaned.slice(1)}` };
    } else {
      return { valid: false, formatted: phoneNumber };
    }
  };

  const addContact = async () => {
    if (!formData.name.trim()) {
      setFormError("Name is required");
      return;
    }
    if (!formData.contact_phone.trim()) {
      setFormError("Phone number is required");
      return;
    }

    const validation = validatePhoneNumber(formData.contact_phone);
    if (!validation.valid) {
      setFormError("Invalid phone number. Please enter a valid Nigerian number (e.g., 08012345678 or 08123456789)");
      return;
    }

    setSubmitting(true);
    setFormError("");

    try {
      const payload = {
        phone: phone,
        name: formData.name.trim(),
        contact_phone: validation.formatted,
      };

      const response = await fetch(`${API_BASE}/trusted-contacts`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.success) {
        await fetchContact();
        setShowAddModal(false);
        setNewContactName(formData.name);
        setNewContactPhone(payload.contact_phone);
        setVerificationToken(data.data?.verification_token || null);
        setInviteSent(false);
        setShowInviteModal(true);
        setFormData({ name: "", contact_phone: "" });
        setFormError("");
      } else {
        if (data.message === "Unauthenticated.") { setFormError("Please log in again to add a trusted contact."); } else { setFormError(data.error || data.message || "Failed to add contact"); };
      }
    } catch (error) {
      console.error("Error adding contact:", error);
      setFormError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const removeContact = async () => {
    if (!contact || !contact.id) return;

    setSubmitting(true);

    try {
      const response = await fetch(`${API_BASE}/trusted-contacts/${contact.id}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
        body: JSON.stringify({ phone: phone }),
      });

      const data = await response.json();

      if (data.success) {
        setContact(null);
        setShowRemoveConfirm(false);
        setUsed(0);
      } else {
        setFormError(data.error || "Failed to remove contact");
      }
    } catch (error) {
      console.error("Error removing contact:", error);
      setFormError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleShareInvite = () => {
    const inviteLink = `https://kin.app/invite?ref=${phone}`;
    
    if (navigator.share) {
      navigator.share({
        title: "Join my KIN safety network",
        text: `${contact?.name || "Contact"}, join my trusted safety network on KIN.`,
        url: inviteLink,
      }).catch(() => {
        fallbackCopy(inviteLink);
      });
    } else {
      fallbackCopy(inviteLink);
    }
  };

  const fallbackCopy = (link) => {
    navigator.clipboard.writeText(link).then(() => {
      setShareMessage("✅ Invite link copied! Share it with your contact.");
      setTimeout(() => setShareMessage(""), 3000);
    }).catch(() => {
      setShareError("Could not copy link. Please copy it manually.");
      setTimeout(() => setShareError(""), 3000);
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F0F7F2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-10 h-10 border-3 border-[#1A5632] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-[#1A5632] text-sm">Loading...</p>
        </div>
      </div>
    );
  }

  const hasContact = contact !== null;
  const isVerified = contact?.verified === true;

  return (
    <div className="min-h-screen bg-[#F0F7F2] pb-20">
      {/* Header */}
      <div className="bg-white px-5 py-4 border-b border-[#E9ECEF] sticky top-0 z-10 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="text-[#1A5632] text-xl">
          <FaArrowLeft />
        </button>
        <h1 className="text-lg font-bold text-[#1A5632]">Trusted Contact</h1>
      </div>

      <div className="px-5 py-6 max-w-md mx-auto">
        {!hasContact ? (
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E9ECEF] text-center">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-[#E8F3EA] flex items-center justify-center">
              <FaUserCircle className="text-4xl text-[#1A5632]" />
            </div>
            <h3 className="text-lg font-bold text-[#1A1A1A] mb-2">No Trusted Contact</h3>
            <p className="text-sm text-[#6C757D] mb-6">
              Add your first trusted contact to activate full protection.
            </p>
            <button
              onClick={() => setShowAddModal(true)}
              className="w-full h-12 rounded-xl bg-[#1A5632] text-white font-semibold text-base shadow-lg hover:opacity-90 active:scale-95 transition-all"
            >
              Add Trusted Contact
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#E9ECEF]">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-full bg-[#E8F3EA] flex items-center justify-center">
                  <FaUserCircle className="text-3xl text-[#1A5632]" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#1A1A1A]">{contact.name}</h3>
                  <p className="text-sm text-[#6C757D]">📱 {contact.phone}</p>
                </div>
              </div>
              <div className="text-right">
                <span className={`inline-flex items-center gap-1 text-xs font-medium px-3 py-1 rounded-full ${
                  isVerified ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                }`}>
                  {isVerified ? <FaCheckCircle /> : <FaExclamationTriangle />}
                  {isVerified ? "Active ✓" : "Pending"}
                </span>
              </div>
            </div>

            <div className={`p-3 rounded-xl mb-4 text-sm ${
              isVerified ? "bg-green-50 text-green-700" : "bg-yellow-50 text-yellow-700"
            }`}>
              {isVerified 
                ? "Contact is protected by KIN." 
                : "Share KIN with this contact so they can join your safety network."}
            </div>

            {/* Share Invite Link button removed: the invite link is only valid
                immediately after the contact is added (shown via InviteModal).
                Re-sharing here used a placeholder link with no real
                verification token, which never worked. */}

            {shareMessage && (
              <p className="text-green-600 text-sm text-center mb-3">{shareMessage}</p>
            )}
            {shareError && (
              <p className="text-red-500 text-sm text-center mb-3">{shareError}</p>
            )}

            <button
              onClick={() => setShowRemoveConfirm(true)}
              className="w-full h-12 rounded-xl bg-gray-100 text-[#6C757D] font-semibold text-base flex items-center justify-center gap-3 hover:bg-gray-200 active:scale-95 transition-all"
            >
              <FaSync />
              Replace Contact
            </button>

            {!canRemove && daysUntilRemoval > 0 && (
              <p className="text-xs text-[#6C757D] text-center mt-3">
                <FaClock className="inline mr-1" />
                Can remove in {Math.ceil(daysUntilRemoval)} days
              </p>
            )}
          </div>
        )}
      </div>

      {/* Add Contact Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
            <h2 className="text-xl font-bold text-[#1A1A1A] text-center mb-4">Add Trusted Contact</h2>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-[#6C757D] mb-1">Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Full name"
                className="w-full h-12 px-4 rounded-xl border border-[#E9ECEF] focus:border-[#1A5632] focus:ring-1 focus:ring-[#1A5632] outline-none"
                autoFocus
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-[#6C757D] mb-1">Phone Number</label>
              <input
                type="tel"
                value={formData.contact_phone}
                onChange={(e) => setFormData({ ...formData, contact_phone: e.target.value })}
                placeholder="08012345678" maxLength="11"
                className="w-full h-12 px-4 rounded-xl border border-[#E9ECEF] focus:border-[#1A5632] focus:ring-1 focus:ring-[#1A5632] outline-none"
              />
              <p className="text-xs text-[#6C757D] mt-1">Enter Nigerian number (e.g., 08012345678)</p>
            </div>

            {formError && (
              <p className="text-red-500 text-sm text-center mb-4">{formError}</p>
            )}

            <button
              onClick={addContact}
              disabled={submitting}
              className="w-full h-12 rounded-xl bg-[#1A5632] text-white font-semibold text-base shadow-lg hover:opacity-90 active:scale-95 transition-all disabled:opacity-50"
            >
              {submitting ? "Adding..." : "Add Contact"}
            </button>

            <button
              onClick={() => {
                setShowAddModal(false);
                setFormError("");
                setFormData({ name: "", contact_phone: "" });
              }}
              className="w-full py-3 text-sm font-medium text-[#6C757D] hover:text-[#1A5632] transition-colors mt-2"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Remove/Replace Confirmation Modal */}
      {showRemoveConfirm && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
              <FaTrash className="text-2xl text-red-500" />
            </div>
            <h2 className="text-xl font-bold text-[#1A1A1A] mb-2">Replace Contact</h2>
            <p className="text-sm text-[#6C757D] mb-4">
              Are you sure you want to remove <strong>{contact?.name}</strong> from your trusted network?
            </p>
            {!canRemove && (
              <p className="text-xs text-yellow-600 bg-yellow-50 p-2 rounded-lg mb-4">
                <FaClock className="inline mr-1" />
                You can remove this contact in {daysUntilRemoval} days.
              </p>
            )}
            <button
              onClick={removeContact}
              disabled={!canRemove || submitting}
              className="w-full h-12 rounded-xl bg-red-500 text-white font-semibold text-base shadow-lg hover:bg-red-600 active:scale-95 transition-all disabled:opacity-50"
            >
              {submitting ? "Removing..." : "Yes, Replace Contact"}
            </button>
            <button
              onClick={() => setShowRemoveConfirm(false)}
              className="w-full py-3 text-sm font-medium text-[#6C757D] hover:text-[#1A5632] transition-colors mt-2"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <InviteModal
        isOpen={showInviteModal}
        contactName={newContactName}
        contactPhone={newContactPhone}
        inviteMessage={inviteMessage}
        inviteSent={inviteSent}
        onSmsShare={handleSmsShare}
        onWhatsappShare={handleWhatsappShare}
        onContinueSetup={handleInviteContinue}
      />
    <BottomNav activeTab="network" />
    </div>
  );
}

export default NetworkScreenV2;
