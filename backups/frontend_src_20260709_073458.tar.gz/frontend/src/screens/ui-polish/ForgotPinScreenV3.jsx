import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { FaArrowLeft, FaSpinner, FaShieldAlt, FaCheckCircle, FaUser } from "react-icons/fa";

const API_BASE = import.meta.env.VITE_API_URL;

function ForgotPinScreenV3() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [identifier, setIdentifier] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [pinError, setPinError] = useState("");

  const otpRefs = useRef([]);
  const pinRef = useRef(null);
  const confirmPinRef = useRef(null);

  useEffect(() => {
    if (step === 2 && otpRefs.current[0]) otpRefs.current[0].focus();
  }, [step]);

  useEffect(() => {
    if (step === 3 && pinRef.current) pinRef.current.focus();
  }, [step]);

  const startCountdown = () => {
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) { clearInterval(interval); return 0; }
        return prev - 1;
      });
    }, 1000);
  };

  const isWeakPin = (pin) => {
    const weakPatterns = [
      /^(\d)\1{3}$/, /^1234$/, /^4321$/, /^0000$/,
      /^0123$/, /^9876$/, /^5678$/,
      /^(19|20)\d{2}$/,
    ];
    return weakPatterns.some(pattern => pattern.test(pin));
  };

  const validatePin = (pin) => {
    if (pin.length !== 4) return "PIN must be 4 digits";
    if (isWeakPin(pin)) return "PIN is too weak";
    return null;
  };

  const normalizeIdentifier = (value) => {
    const trimmed = value.trim();
    // If it looks like a phone (digits, possibly with + and spaces), normalize to +234 format
    const digitsOnly = trimmed.replace(/\D/g, "");
    const looksLikeEmail = trimmed.includes("@");

    if (looksLikeEmail) return trimmed;

    // Phone path: accept "0800...", "800...", or "+234800..." and normalize to +234
    if (digitsOnly.startsWith("234")) return `+${digitsOnly}`;
    if (digitsOnly.startsWith("0")) return `+234${digitsOnly.slice(1)}`;
    return `+234${digitsOnly}`;
  };

  const isValidIdentifier = (value) => {
    const trimmed = value.trim();
    if (trimmed.includes("@")) {
      return trimmed.includes(".") && trimmed.length >= 5;
    }
    const digitsOnly = trimmed.replace(/\D/g, "");
    return digitsOnly.length >= 10;
  };

  const handleOtpChange = (index, value) => {
    const newOtp = [...otp];
    newOtp[index] = value.replace(/\D/g, "").slice(0, 1);
    setOtp(newOtp);
    setError("");
    if (value && index < 5) otpRefs.current[index + 1]?.focus();
    const fullOtp = newOtp.join("");
    if (fullOtp.length === 6 && index === 5) handleVerifyOtp(fullOtp);
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const sendOtp = async () => {
    if (!isValidIdentifier(identifier)) {
      setError("Enter a valid email or phone number");
      return;
    }
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      const normalized = normalizeIdentifier(identifier);
      const response = await fetch(`${API_BASE}/forgot-pin/send-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: normalized }),
      });
      const data = await response.json();
      if (response.ok) {
        if (data.cooldown_remaining) {
          const wait = Math.ceil(data.cooldown_remaining);
          setError(`Please wait ${wait}s before requesting another code`);
          setCountdown(wait);
          startCountdown();
        } else {
          setSuccess(`Code sent to ${identifier}`);
          setStep(2);
          setCountdown(60);
          startCountdown();
        }
      } else {
        setError(data.message || "Failed to send code");
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (fullOtp) => {
    if (fullOtp.length !== 6) return;
    setLoading(true);
    setError("");
    try {
      const normalized = normalizeIdentifier(identifier);
      const response = await fetch(`${API_BASE}/forgot-pin/verify-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identifier: normalized,
          otp: fullOtp,
        }),
      });
      const data = await response.json();
      if (response.ok) {
        setSuccess("Verification successful");
        setStep(3);
      } else {
        setError("Invalid code. Please try again.");
        setOtp(["", "", "", "", "", ""]);
        otpRefs.current[0]?.focus();
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleResetPin = async () => {
    const pinValidation = validatePin(newPin);
    if (pinValidation) { setPinError(pinValidation); return; }
    setPinError("");
    if (newPin !== confirmPin) { setPinError("PINs do not match"); return; }

    setLoading(true);
    setError("");
    try {
      const normalized = normalizeIdentifier(identifier);
      const response = await fetch(`${API_BASE}/forgot-pin/reset`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identifier: normalized,
          otp: otp.join(""),
          pin: newPin,
        }),
      });
      const data = await response.json();
      if (response.ok) {
        setShowSuccess(true);
      } else {
        setError(data.message || "Failed to reset PIN");
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (countdown > 0) return;
    await sendOtp();
  };

  if (showSuccess) {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-[#F0F7F2] to-[#E8F3EA] flex flex-col items-center justify-center px-6">
        <div className="absolute top-[-100px] left-[-100px] w-80 h-80 bg-[#1A5632]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-[-100px] right-[-100px] w-80 h-80 bg-[#D4A017]/10 rounded-full blur-3xl" />
        <div className="w-full max-w-md relative z-10 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center">
            <FaCheckCircle className="text-4xl text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-[#1A1A1A]">Your account is secure again.</h2>
          <button
            onClick={() => navigate("/login")}
            className="mt-6 w-full h-12 rounded-xl bg-gradient-to-r from-[#1A5632] to-[#0E3A22] text-white font-semibold text-base shadow-lg shadow-[#1A5632]/20 active:scale-95 transition-all"
          >
            Continue to Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-[#F0F7F2] to-[#E8F3EA] flex flex-col">
      <div className="absolute top-[-100px] left-[-100px] w-80 h-80 bg-[#1A5632]/10 rounded-full blur-3xl" />
      <div className="absolute bottom-[-100px] right-[-100px] w-80 h-80 bg-[#D4A017]/10 rounded-full blur-3xl" />

      <button
        onClick={() => navigate(-1)}
        className="absolute top-6 left-6 z-10 w-10 h-10 rounded-full bg-white/80 backdrop-blur-sm shadow-md flex items-center justify-center active:scale-95 transition-all"
      >
        <span className="material-symbols-outlined text-[#1A5632] text-2xl">arrow_back</span>
      </button>

      <div className="flex-1 flex flex-col items-center justify-center px-6">
        <div className="w-full max-w-sm">
          {/* Logo */}
          <div className="text-center mb-6">
            <div className="w-14 h-14 mx-auto mb-2 rounded-full bg-gradient-to-br from-[#1A5632] to-[#0E3A22] shadow-lg flex items-center justify-center">
              <FaShieldAlt className="text-white text-2xl" />
            </div>
            <h1 className="text-lg font-black text-[#1A5632] tracking-[0.2em]">KIN</h1>
            <p className="text-[#6C757D] text-[10px] mt-0.5">Personal Safety Network</p>
          </div>

          {/* Step Content */}
          <div className="text-center">
            <h2 className="text-xl font-bold text-[#1A1A1A]">
              {step === 1 ? "Recover Access" : step === 2 ? "Security Verification" : "Protect Your Account"}
            </h2>
            <p className="text-sm text-[#6C757D] mt-1">
              {step === 1 ? "Enter your phone number or email to regain access." :
               step === 2 ? "We've sent a verification code to protect your account." :
               "Choose a secure 4-digit PIN."}
            </p>
          </div>

          {/* Step 1: Email OR Phone */}
          {step === 1 && (
            <div className="mt-6">
              <div className="bg-white rounded-xl px-4 py-3 shadow-sm border border-[#E9ECEF] flex items-center gap-3">
                <FaUser className="text-[#1A5632] text-sm" />
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="Phone number or email"
                  className="flex-1 border-none outline-none bg-transparent text-base"
                  autoFocus
                  onKeyDown={(e) => e.key === "Enter" && sendOtp()}
                />
              </div>
            </div>
          )}

          {/* Step 2: OTP */}
          {step === 2 && (
            <div className="mt-6">
              <div className="flex justify-center gap-3">
                {[0, 1, 2, 3, 4, 5].map((index) => (
                  <input
                    key={index}
                    ref={(el) => (otpRefs.current[index] = el)}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={otp[index]}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(index, e)}
                    className="w-12 h-12 text-center text-2xl font-semibold border border-[#E9ECEF] rounded-xl bg-white shadow-sm focus:border-[#1A5632] focus:ring-1 focus:ring-[#1A5632] outline-none"
                  />
                ))}
              </div>
              <p className="text-xs text-[#6C757D] mt-3 text-center">
                {countdown > 0 ? (
                  `Resend in ${countdown}s`
                ) : (
                  <button onClick={handleResend} className="text-[#1A5632] font-medium hover:underline">
                    Resend Code
                  </button>
                )}
              </p>
            </div>
          )}

          {/* Step 3: New PIN */}
          {step === 3 && (
            <div className="mt-6 space-y-3">
              <div className="bg-white rounded-xl px-4 py-3 shadow-sm border border-[#E9ECEF]">
                <input
                  ref={pinRef}
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  value={newPin}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, "");
                    setNewPin(value);
                    setPinError("");
                    if (value.length === 4) confirmPinRef.current?.focus();
                  }}
                  placeholder="New PIN"
                  className="w-full border-none outline-none bg-transparent text-2xl text-center tracking-[0.5em]"
                />
              </div>
              <div className="bg-white rounded-xl px-4 py-3 shadow-sm border border-[#E9ECEF]">
                <input
                  ref={confirmPinRef}
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  value={confirmPin}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, "");
                    setConfirmPin(value);
                    setPinError("");
                  }}
                  placeholder="Confirm PIN"
                  className="w-full border-none outline-none bg-transparent text-2xl text-center tracking-[0.5em]"
                  onKeyDown={(e) => e.key === "Enter" && handleResetPin()}
                />
              </div>
              {pinError && (
                <p className="text-yellow-600 text-sm text-center">{pinError}</p>
              )}
            </div>
          )}

          {/* Error / Success */}
          {error && (
            <p className="text-red-500 text-sm text-center mt-4">{error}</p>
          )}
          {success && step !== 3 && (
            <p className="text-green-600 text-sm text-center mt-4">{success}</p>
          )}

          {/* Action Button */}
          <button
            onClick={step === 1 ? sendOtp : step === 2 ? () => {} : handleResetPin}
            disabled={loading || (step === 2 && otp.join("").length !== 6)}
            className="mt-6 w-full h-12 rounded-xl bg-gradient-to-r from-[#1A5632] to-[#0E3A22] text-white font-semibold text-base shadow-lg shadow-[#1A5632]/20 hover:opacity-90 active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? (
              <FaSpinner className="animate-spin" />
            ) : step === 1 ? (
              "Send Code"
            ) : step === 2 ? (
              "Verifying..."
            ) : (
              "Update PIN"
            )}
          </button>

          {/* Log In Link */}
          <p className="text-center text-sm text-[#6C757D] mt-4">
            Already have an account?{' '}
            <button onClick={() => navigate("/login")} className="text-[#1A5632] font-semibold hover:underline">
              Log In
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

export default ForgotPinScreenV3;
